# teksys1
Skills Based Assessment #1 Tek Systems Java Course

Find the compliled HTML, JS and CSS in the dist directory
The TypeScript, Pug and SCSS in the src directory. 

# Main pages include 
- Home (of course) which is index.html
- Sign Up
- Popular

Rest are just filler or templates for future pages