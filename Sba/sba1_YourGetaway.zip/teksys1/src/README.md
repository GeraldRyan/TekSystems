***Pug watch command***
pug -w {current_dir} -o {dest_dir} -P  
e.g.  
```pug -w ./ -o ../dist -P```  

***Sass watch command***
sass --watch src/:/dist  
e.g. if in src directory:  
  ```sass --watch ./:../dist```  